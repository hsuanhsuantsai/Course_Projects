//
//  Analysis.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/4.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class AnalysisViewController: UIViewController {

    //Third party framework: class LineChart
    @IBOutlet weak var weightChart: LineChart!
    @IBOutlet weak var bodyFatChart: LineChart!
    
    var myRecord: [Record] = []
    
    //redraw line charts for newly added records
    @IBAction func refresh(_ sender: UIBarButtonItem) {
        print("refresh")
        let newWeightChart = LineChart(frame: weightChart.frame)
        let newBodyChart = LineChart(frame: bodyFatChart.frame)
        reload()
        drawChart(item: "weight", lineChart: newWeightChart, deltaX: 1, deltaY: 5)
        drawChart(item: "bodyFat", lineChart: newBodyChart, deltaX: 1, deltaY: 1)
        self.view.addSubview(newWeightChart)
        self.view.addSubview(newBodyChart)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reload()
        drawChart(item: "weight", lineChart: weightChart, deltaX: 1, deltaY: 5)
        drawChart(item: "bodyFat", lineChart: bodyFatChart, deltaX: 1, deltaY: 1)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //read archived data and draw line charts
    func reload(){
        let tempController = self.tabBarController?.viewControllers?[0] as! UINavigationController
        let tab1Controller = tempController.viewControllers.first as! myMenuSetViewController
        readData(key: "myRecord_" + tab1Controller.str)
    }
    
    //read archived data from local device
    func readData(key: String){
        let fileManager = FileManager.default
        let readPath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(key)
        print(readPath)
        if fileManager.fileExists(atPath: readPath),
            let tempRecord = NSKeyedUnarchiver.unarchiveObject(withFile: readPath) {
            myRecord = tempRecord as! [Record]
        }
    }

    //draw line chart with given string
    func drawChart(item: String, lineChart: LineChart, deltaX: Int, deltaY: Int){
        lineChart.lineColor = UIColor.red
        lineChart.lineWidth = 10
        lineChart.showPoints = true
        lineChart.circleColor = UIColor.green
        lineChart.circleSizeMultiplier = 10
        lineChart.axisColor = UIColor.black
        lineChart.backgroundColor = UIColor.white
        
        
        var points: [CGPoint] = []
        
        switch item {
        case "weight" :
            for index in 0..<myRecord.count {
                let point = CGPoint(x: Double(index), y: myRecord[index].weight)
                points.append(point)
            }
        case "bodyFat" :
            for index in 0..<myRecord.count {
                let point = CGPoint(x: Double(index), y: myRecord[index].bodyFat)
                points.append(point)
            }
        case "sleep" :
            for index in 0..<myRecord.count {
                let point = CGPoint(x: Double(index), y: Double(myRecord[index].sleep))
                points.append(point)
            }
        default:
            print("Do nothing.")
        }
        
        //Third party framework
        lineChart.deltaX = CGFloat(deltaX)
        lineChart.deltaY = CGFloat(deltaY)
        lineChart.plot(points)
    }


}
