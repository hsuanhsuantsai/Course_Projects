//
//  goal.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/6.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import Foundation

///Goal: The biggest data structure in this app
class Goal: NSObject, NSCoding {
    
    /**
        Members in Goal
        - title: Name of a Goal
        - menu_set: Store user-created Menus concerning body parts
      */
    var title: String = ""
    var menu_set: [Menu] = []
    
    init(title: String, menu_set: [Menu]) {
        self.title = title
        self.menu_set = menu_set
    }
    
    //For decode purpose
    required convenience init (coder aDecoder: NSCoder) {
        let title = aDecoder.decodeObject(forKey: "title") as! String
        let menu_set = aDecoder.decodeObject(forKey: "menu_set") as! [Menu]
        self.init(title: title, menu_set: menu_set)
    }
    
    //For encode purpose
    func encode(with aCoder: NSCoder) {
        aCoder.encode(title, forKey: "title")
        aCoder.encode(menu_set, forKey: "menu_set")
    }
    
}
