//
//  menu.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/4.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import Foundation

///Menu: A set of equipments and their data for specific body part
class Menu: NSObject, NSCoding {
    
    /**
        Members in Menu
        -title: Name of desired body part
        -equipment: A set of desired equipments for training the body part
        -set: How many sets for corresponding equipment
        -repetitions: How many repetitions for corresponding equipment
      */
    var title: String = ""
    var equipment: [String] = []
    var set: [Int] = []
    var repetitions: [Int] = []
    
    init?(title: String, equipment: [String], set: [Int], repetitions: [Int]) {
        
        guard !title.isEmpty else {
            return nil
        }
        
        // Initialize stored properties.
        self.title = title
        self.equipment = equipment
        self.set = set
        self.repetitions = repetitions
        
    }
    
    //For decode purpose
    required convenience init (coder aDecoder: NSCoder) {
        let title = aDecoder.decodeObject(forKey: "title") as! String
        let equipment = aDecoder.decodeObject(forKey: "equipment") as! [String]
        let set = aDecoder.decodeObject(forKey: "set") as! [Int]
        let repetitions = aDecoder.decodeObject(forKey: "repetitions") as! [Int]
        self.init(title: title, equipment: equipment, set: set, repetitions: repetitions)!
    }
    
    //For encode purpose
    func encode(with aCoder: NSCoder) {
        aCoder.encode(title, forKey: "title")
        aCoder.encode(equipment, forKey: "equipment")
        aCoder.encode(set, forKey: "set")
        aCoder.encode(repetitions, forKey: "repetitions")
    }
}
