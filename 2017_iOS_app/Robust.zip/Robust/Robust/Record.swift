//
//  record.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/4.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import Foundation
import UIKit

///Record: A personal spreadsheet corresponding to a defined menu
class Record: NSObject, NSCoding {
    
    /**
        Members of Record
        -title: Name of the record
        -menu: The module of the record. The equipments in tab2 come from here
        -set: Sets for its corresponding equipment
        -repetitions: Repetitions for its corresponding equipment
        -sleep: Sleep hour of last night
        -weight: Current weight
        -bodyFat: Current body fat percentage
        -fatigue: Current weariness
      */
    var title: String = ""
    var menu: Menu?
    var set: [Int] = []
    var repetitions: [Int] = []
    var sleep: Int = 0
    var weight: Double = 0
    var bodyFat: Double = 0
    var fatigue: Int = 0
    var photo: UIImage?
    
    init(title: String, menu: Menu?, set: [Int], repetitions: [Int], sleep: Int, weight: Double, bodyFat: Double, fatigue: Int, photo: UIImage?) {
        self.title = title
        self.menu = menu
        self.set = set
        self.repetitions = repetitions
        self.sleep = sleep
        self.weight = weight
        self.bodyFat = bodyFat
        self.fatigue = fatigue
        self.photo = photo
    }
    
    //For decode purpose
    required convenience init (coder aDecoder: NSCoder) {
        let title = aDecoder.decodeObject(forKey: "title") as! String
        let menu = aDecoder.decodeObject(forKey: "menu") as! Menu
        let set = aDecoder.decodeObject(forKey: "set") as! [Int]
        let repetitions = aDecoder.decodeObject(forKey: "repetitions") as! [Int]
        let sleep = aDecoder.decodeInteger(forKey: "sleep")
        let weight = aDecoder.decodeDouble(forKey: "weight")
        let bodyFat = aDecoder.decodeDouble(forKey: "bodyFat")
        let fatigue = aDecoder.decodeInteger(forKey: "fatigue")
        let photo = aDecoder.decodeObject(forKey: "photo") as! UIImage
        self.init(title: title, menu: menu, set: set, repetitions: repetitions, sleep: sleep, weight: weight, bodyFat: bodyFat, fatigue: fatigue, photo: photo)
    }
    
    //For encode purpose
    func encode(with aCoder: NSCoder) {
        aCoder.encode(title, forKey: "title")
        aCoder.encode(menu, forKey: "menu")
        aCoder.encode(set, forKey: "set")
        aCoder.encode(repetitions, forKey: "repetitions")
        aCoder.encode(sleep, forKey: "sleep")
        aCoder.encode(weight, forKey: "weight")
        aCoder.encode(bodyFat, forKey: "bodyFat")
        aCoder.encode(fatigue, forKey: "fatigue")
        aCoder.encode(photo, forKey: "photo")
    }
}
