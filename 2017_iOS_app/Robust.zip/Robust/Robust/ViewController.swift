//
//  ViewController.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/13.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var launchImg: UIImageView!
    @IBOutlet weak var infoView: UIView!
   
    //gocha from info view
    @IBAction func gotcha(_ sender: UIButton) {
        print("gotcha")
        customViewAnimated(position: -450)
    }
    
    //show app instructions
    @IBAction func info(_ sender: UIButton) {
        print("info")
        customViewAnimated(position: 667/2)
    }
    
    @IBAction func printAction(_ sender: UIButton){
        print("New training split")
    }
    
    @IBAction func printAction2(_ sender: UIButton){
        print("Owned training split")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            sleep(4)
            self.launchImg.alpha = 0
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //movement of custom view
    func customViewAnimated(position: Int){
        guard let infoView = infoView else{
            return
        }
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseOut, animations: {()-> Void
            in infoView.center.y = CGFloat(position)}, completion: nil)
    }

}
