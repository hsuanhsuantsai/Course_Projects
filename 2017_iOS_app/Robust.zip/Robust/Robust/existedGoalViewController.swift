//
//  ViewController.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/4.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class existedGoalViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var goal_list: [String] = []

    @IBOutlet weak var tableView: UITableView!
    
    //leave the view controller
    @IBAction func goBack(_ sender: UIBarButtonItem) {
        print("goBack")
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = UITableViewAutomaticDimension
        
        let fileManager = FileManager.default
        let readPath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("goal_list")
        print(readPath)
        if fileManager.fileExists(atPath: readPath),
            let goal_list = NSKeyedUnarchiver.unarchiveObject(withFile: readPath) {
            self.goal_list = goal_list as! [String]
        }
        
        if !goal_list.isEmpty {
            tableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "existedBody" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let goal_title = goal_list[indexPath.row]
                
                //access selected goal data
                let fileManager = FileManager.default
                let readPath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(goal_title)
                print(readPath)
                var goal = Goal(title: "", menu_set: [])
                if fileManager.fileExists(atPath: readPath),
                    let temp = NSKeyedUnarchiver.unarchiveObject(withFile: readPath) {
                     goal =  temp as! Goal
                }
                
///Attribution: http://stackoverflow.com/questions/27307903/swift-tab-bar-view-prepareforsegue
                let tabBarController = segue.destination as! UITabBarController
                // Gets the first view controller in the tabbar (this is a UINavigationController)
                let navController = tabBarController.viewControllers?[0] as! UINavigationController
                
                let controller = navController.viewControllers[0] as! myMenuSetViewController
                
                controller.menu_set = goal.menu_set
                controller.str = goal_title
            }
        }
    }

    //table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return goal_list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "existedGoalCell", for: indexPath) as! existedGoalCell
        
        let goal_title = goal_list[indexPath.row]
        cell.goalLabel.text = goal_title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            let fileManager = FileManager.default
            //delete the goal file in local device
            let goalPath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(goal_list[indexPath.row])
            print(goalPath)
            do {
                print("deleting goal file")
                try fileManager.removeItem(atPath: goalPath)
            }
            catch let error as NSError{
                print("remove goal file failed: \(error)")
            }
            
            //delete related record file in local device
            let goal_recordPath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("myRecord_" + goal_list[indexPath.row])
            print(goal_recordPath)
            do {
                print("deleting related record file")
                try fileManager.removeItem(atPath: goal_recordPath)
            }
            catch let error as NSError{
                print("remove related record file failed: \(error)")
            }
            
            //refresh goal_list file to local device
            goal_list.remove(at: indexPath.row)
            let Path = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("goal_list")
            print(Path)
            let data = NSKeyedArchiver.archivedData(withRootObject: goal_list)
            fileManager.createFile(atPath: Path as String, contents: data, attributes: nil)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
}

