//
//  myMenuSetDetail.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/12.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class myMenuSetDetail: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var customView: UIView!
    @IBOutlet weak var equipmentLabel: UILabel!
    @IBOutlet weak var setLabel: UILabel!
    @IBOutlet weak var repetitionsLabel: UILabel!
    
    var equipment: [String] = []
    var set: [Int] = []
    var repetitions: [Int] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = UITableViewAutomaticDimension
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return equipment.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "equipmentCell", for: indexPath) as! equipmentCell
        cell.title.text = equipment[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return false
    }
    
    //further implementation
    /*
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            equipment.remove(at: indexPath.row)
            set.remove(at: indexPath.row)
            repetitions.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }*/

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        customViewAnimated(position: 300)
        equipmentLabel.text = equipment[indexPath.row]
        setLabel.text = "Set(s):" + String(set[indexPath.row])
        repetitionsLabel.text = "Reps: " + String(repetitions[indexPath.row])
    }
    
    //movement of custom view
    func customViewAnimated(position: Int){
        guard let infoView = customView else{
            return
        }
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseOut, animations: {()-> Void
            in infoView.center.y = CGFloat(position)}, completion: nil)
    }
    
    //leave the view controller
    @IBAction func back(_ sender: UIBarButtonItem) {
        print("back")
        dismiss(animated: true, completion: nil)
    }
    
    //dismiss custom view
    @IBAction func OK(_ sender: UIButton) {
        print("OK")
        customViewAnimated(position: -500)
    }
}
