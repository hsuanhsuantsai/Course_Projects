//
//  existedBodyViewController.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/11.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class myMenuSetViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!

    var menu_set: [Menu] = []
    var str: String = ""
    
    //leave the view controller
    @IBAction func back(_ sender: UIBarButtonItem) {
        print("back")
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = str
        tableView.rowHeight = UITableViewAutomaticDimension
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "showEquip" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let menu = menu_set[indexPath.row]
                let controller = (segue.destination as! UINavigationController).topViewController as! myMenuSetDetail
                controller.equipment = menu.equipment
                controller.set = menu.set
                controller.repetitions = menu.repetitions
            }
        }
    }
 
    //table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menu_set.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "existedBodyCell", for: indexPath) as! existedBodyCell
        
        let menu = menu_set[indexPath.row]
        cell.bodyPart.text = menu.title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return false
    }
    
    //further implementation
    /*
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            menu_set.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }*/
    
    
}
