//
//  myRecord.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/4.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class myRecordViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var customView: UIView!
    @IBOutlet weak var bodyPicker: UIPickerView!
    
    var myRecord: [Record] = []
    var menu_set: [Menu] = []
    var index: Int = 0
    var myGoal: String = ""

///Attribution: http://stackoverflow.com/questions/40658933/data-transfer-between-child-tabs-in-a-tab-bar-controller
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tempController = self.tabBarController?.viewControllers?[0] as! UINavigationController
        let tab1Controller = tempController.viewControllers[0] as! myMenuSetViewController
        self.menu_set = tab1Controller.menu_set
        self.myGoal = tab1Controller.str
        let fileManager = FileManager.default
        let readPath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("myRecord_" + myGoal)
        print(readPath)
        if fileManager.fileExists(atPath: readPath),
            let tempRecord = NSKeyedUnarchiver.unarchiveObject(withFile: readPath) {
            myRecord = tempRecord as! [Record]
        }
        
        self.tableView.estimatedRowHeight = 44
        tableView.rowHeight = UITableViewAutomaticDimension
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //picker view
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return menu_set.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return menu_set[row].title
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        index = row
    }
    
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "recordDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let controller = (segue.destination as! UINavigationController).topViewController as! recordDetailViewController
                let record = myRecord[indexPath.row]
                let menu = myRecord[indexPath.row].menu
                controller.equipment = (menu?.equipment)!
                controller.navigationItem.title = menu?.title
                if record.set.isEmpty { //first entry
                    controller.set = [Int](repeating: 0, count: (menu?.equipment.count)!)
                    controller.repetitions = [Int](repeating: 0, count: (menu?.equipment.count)!)
                    controller.first_time = true
                }
                else {
                    controller.set = record.set
                    controller.repetitions = record.repetitions
                    controller.sleep = record.sleep
                    controller.weight_value = record.weight
                    controller.bodyFat_value = record.bodyFat
                    controller.fatigue_value = record.fatigue
                    if let pic = record.photo {
                        controller.img = pic
                    }
                }
            }
        }
    }
 
    //table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myRecord.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "myRecordCell", for: indexPath) as! myRecordCell
        let record = myRecord[indexPath.row]
        cell.recordTitle.text = record.title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            myRecord.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    //call custom view to show up
    @IBAction func addRecord(_ sender: UIBarButtonItem) {
        print("addRecord")
        customViewAnimated(position: 300)
    }
    
    //movement of custom view
    func customViewAnimated(position: Int){
        guard let infoView = customView else{
            return
        }
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseOut, animations: {()-> Void
            in infoView.center.y = CGFloat(position)}, completion: nil)
    }
    
    //create a new personal record (OK button in custom view)
    @IBAction func createRecord(_ sender: UIButton) {
        print("createRecord")
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        let date = dateFormatter.string(from: Date())
        let record = Record(title: date + " - " + menu_set[index].title, menu: menu_set[index], set: [], repetitions: [], sleep: 0, weight: 0.0, bodyFat: 0.0, fatigue: 0, photo: nil)
        myRecord.append(record)
        customViewAnimated(position: -500)
        tableView.reloadData()
    }
    
    //An unwind function for save button in recordDetailViewController
    @IBAction func unwindToList(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.source as? recordDetailViewController {
            if let selectedIndexPath = tableView.indexPathForSelectedRow {
                myRecord[selectedIndexPath.row].set = sourceViewController.set
                myRecord[selectedIndexPath.row].repetitions = sourceViewController.repetitions
                myRecord[selectedIndexPath.row].photo = sourceViewController.myPhoto.image
                if sourceViewController.sleepHour.hasText, let hour = Int(sourceViewController.sleepHour.text!) {
                    myRecord[selectedIndexPath.row].sleep = hour
                }
                else {
                    myRecord[selectedIndexPath.row].sleep = 0
                }
                
                if sourceViewController.weight.hasText, let number3 = Double(sourceViewController.weight.text!) {
                   myRecord[selectedIndexPath.row].weight = number3
                }
                else {
                    myRecord[selectedIndexPath.row].weight = 0.0
                }
                
                if sourceViewController.bodyFat.hasText, let number4 = Double(sourceViewController.bodyFat.text!){
                    myRecord[selectedIndexPath.row].bodyFat = number4
                }
                else {
                    myRecord[selectedIndexPath.row].bodyFat = 0.0
                }
                myRecord[selectedIndexPath.row].fatigue = sourceViewController.fatigue_value
            }
            else {
                print("no sourceViewController")
            }
        }
    }
    
    //leave the view controller
    @IBAction func back(_ sender: UIBarButtonItem) {
        print("back")
        dismiss(animated: true, completion: nil)
    }
    
    //save records to local device
    @IBAction func saveData(_ sender: UIBarButtonItem) {
        print("saveData")
        let fileManager = FileManager.default
        let writePath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("myRecord_" + myGoal)
        let new_records = myRecord
        print(writePath)
        let data = NSKeyedArchiver.archivedData(withRootObject: new_records)
        fileManager.createFile(atPath: writePath as String, contents: data, attributes: nil)
    }
    
}
