//
//  newGoal.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/4.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class newGoalViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate{
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var goal: UITextField!
    var menu_set: [Menu] = []
    var myGoal = Goal(title: "", menu_set: [])
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //let temp = Menu(title: "hello", equipment: ["dumb bell"], set: [2], repetitions: [3])
        //menu_set.append(temp!)
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        if segue.identifier == "newBody" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let menu = menu_set[indexPath.row]
                let controller = (segue.destination as! UINavigationController).topViewController as! newMenuViewController
                controller.menu = menu
            }
        }
    }
    
    //text field
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        myGoal.title = textField.text!
    }
    
    //table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menu_set.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "newGoalCell", for: indexPath) as! newGoalCell
        let menu = menu_set[indexPath.row]
        cell.bodyPart.text = menu.title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            menu_set.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    //An unwind function for save button in newMenuViewController
    @IBAction func unwindToList(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.source as? newMenuViewController, let menu = sourceViewController.menu {
            
            if let selectedIndexPath = tableView.indexPathForSelectedRow {
                menu_set[selectedIndexPath.row] = menu
                tableView.reloadRows(at: [selectedIndexPath], with: .none)
            }
            else {
                // Add a new menu
                let newIndexPath = IndexPath(row: menu_set.count, section: 0)
                menu_set.append(menu)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
                tableView.reloadRows(at: [newIndexPath], with: .top)
            }
        }
    }
    
    //To store goal_list and new goal object with NSKeyArchiver
    @IBAction func save(_ sender: UIBarButtonItem) {
        print("save")
        //store new goal to goal_list
        var temp: [String] = []
        let fileManager = FileManager.default
        let Path = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("goal_list")
        if fileManager.fileExists(atPath: Path),
            let goal_list = NSKeyedUnarchiver.unarchiveObject(withFile: Path) {
            temp = goal_list as! [String]
        }
        print(Path)
        temp.append(myGoal.title)
        let data = NSKeyedArchiver.archivedData(withRootObject: temp)
        fileManager.createFile(atPath: Path as String, contents: data, attributes: nil)
        
        //store new goal object
        myGoal.menu_set = menu_set
        let goal_path = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(myGoal.title)
        let goal_data = NSKeyedArchiver.archivedData(withRootObject: myGoal)
        fileManager.createFile(atPath: goal_path as String, contents: goal_data, attributes: nil)
        print(goal_path)
        dismiss(animated: true, completion: nil)
    }
    
    //leave the view controller without saving data, an UIAlertController will show up
    @IBAction func cancel(_ sender: UIBarButtonItem) {
        print("cancel")
        let alert = UIAlertController(title: "Leave without saving data", message: "Are you sure you want to leave?\nYour training split will not be saved!", preferredStyle: .alert)
        
        let yes = UIAlertAction(title: "Yes", style: .default,
                                handler: {action in
                                    self.dismiss(animated: true, completion: nil)})
        let no = UIAlertAction(title: "No", style: .default,
                                   handler: nil)
        alert.addAction(yes)
        alert.addAction(no)
        present(alert, animated: true, completion: nil)
    }

}
