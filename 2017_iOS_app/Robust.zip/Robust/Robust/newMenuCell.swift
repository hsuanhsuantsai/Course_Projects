//
//  newMenuCell.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/4.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class newMenuCell: UITableViewCell {

    @IBOutlet weak var equipmentLable: UILabel!
    
    @IBOutlet weak var setLabel: UILabel!
    
    @IBOutlet weak var repetitionsLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
