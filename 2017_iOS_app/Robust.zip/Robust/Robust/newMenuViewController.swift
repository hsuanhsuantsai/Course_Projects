//
//  newMenu.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/4.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class newMenuViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {

    var menu: Menu?
    var options: [String] = ["All muscle groups", "Upper-body muscle groups", "Lower-body muscle groups", "Chest", "Shoulders", "Triceps", "Back", "Biceps", "Legs", "Upper trapezius", "Others"]
    var name: String = ""
    var equipment: [String] = []
    var set: [Int] = []
    var repetitions: [Int] = []
    var createNewItem = false
    var index: Int = -1
    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var bodyPartButton: UIButton!
    @IBOutlet weak var bodyPicker: UIPickerView!
    
    //change state of bodyPicker
    @IBAction func setBodyPart(_ sender: UIButton) {
        print("setBodyPart")
        bodyPicker.isHidden = !bodyPicker.isHidden
    }
    
    
    @IBOutlet weak var equipmentText: UITextField!
    @IBOutlet weak var setText: UITextField!
    @IBOutlet weak var repetitionsText: UITextField!
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var customView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let title = menu?.title {
            bodyPartButton.setTitle(title, for: .normal)
        }
        else {
            saveButton.isEnabled = false
        }
        
        if let e = menu?.equipment {
            equipment = e
        }
        
        if let s = menu?.set {
            set = s
        }
        
        if let r = menu?.repetitions {
            repetitions = r
        }
        
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //picker view
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return options.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return options[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        bodyPartButton.setTitle(options[row], for: .normal)
        name = options[row]
        saveButton.isEnabled = true
    }
    
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        guard let button = sender as? UIBarButtonItem, button === saveButton else {
            print("Save button is not tapped.")
            return
        }
        print("prepare")
        menu = Menu(title: name, equipment: equipment, set: set, repetitions: repetitions)
    }
    
    //leave the view controller
    @IBAction func cancelButton(_ sender: UIBarButtonItem) {
        print("cancelButton")
        dismiss(animated: true, completion: nil)
    }
    
    /*
    private func updateSaveButtonState() {
        // Disable the Save button if the text field is empty.
        saveButton.isEnabled = !name.isEmpty
    }*/
 
    //create a new equipment
    @IBAction func addNew(_ sender: UIButton) {
        print("addNew")
        createNewItem = true
        equipmentText.text = ""
        setText.text = ""
        repetitionsText.text = ""
        customViewAnimated(position: 300)
    }
    
    //change local data from data in custom view and reload table
    @IBAction func viewSave(_ sender: UIButton) {
        print("viewSave")
        self.customView.endEditing(true)
        if equipmentText.hasText {
            if createNewItem {
                equipment.append(equipmentText.text!)
            }
            else {
                equipment[index] = equipmentText.text!
            }
        }
        else {
            equipment.append("(Empty)")
        }
        
        if setText.hasText, let number = Int(setText.text!) {
            if createNewItem {
                set.append(number)
            }
            else {
                set[index] = number
            }
        }
        else {
            set.append(0)
        }
        
        if repetitionsText.hasText, let number2 = Int(repetitionsText.text!) {
            if createNewItem {
                repetitions.append(number2)
            }
            else {
                repetitions[index] = number2
            }
        }
        else {
            repetitions.append(0)
        }
        customViewAnimated(position: 1200)
        tableView.reloadData()
    }
    
    //movement of custom view
    func customViewAnimated(position: Int){
        guard let infoView = customView else{
            return
        }
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseOut, animations: {()-> Void
            in infoView.center.y = CGFloat(position)}, completion: nil)
    }
    
    //leave custom view without saving the data
    @IBAction func viewCancel(_ sender: UIButton) {
        print("viewCancel")
        self.customView.endEditing(true)
        customViewAnimated(position: 1200)
    }
    
    //text field
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    //table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return equipment.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "newMenuCell", for: indexPath) as! newMenuCell
        cell.equipmentLable.text = equipment[indexPath.row]
        cell.setLabel.text = String(set[indexPath.row])
        cell.repetitionsLabel.text = String(repetitions[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            equipment.remove(at: indexPath.row)
            set.remove(at: indexPath.row)
            repetitions.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        createNewItem = false
        customViewAnimated(position: 300)
        index = indexPath.row
        equipmentText.text = equipment[index]
        setText.text = String(set[index])
        repetitionsText.text = String(repetitions[index])
    }
}
