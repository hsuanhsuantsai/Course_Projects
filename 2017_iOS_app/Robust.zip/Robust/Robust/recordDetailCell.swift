//
//  recordDetailCell.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/12.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit

class recordDetailCell: UITableViewCell {

    @IBOutlet weak var equipLabel: UILabel!
    @IBOutlet weak var setLabel: UILabel!
    @IBOutlet weak var repLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
