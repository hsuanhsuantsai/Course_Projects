//
//  recordDetailViewController.swift
//  Robust
//
//  Created by Yi-Hsuan Tsai on 2017/3/12.
//  Copyright © 2017年 Flora Tsai. All rights reserved.
//

import UIKit
import Social

class recordDetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var sleepHour: UITextField!
    @IBOutlet weak var weight: UITextField!
    @IBOutlet weak var bodyFat: UITextField!
    @IBOutlet weak var fatigue: UIButton!

    @IBOutlet weak var customView: UIView!
    @IBOutlet weak var setText: UITextField!
    @IBOutlet weak var repText: UITextField!
  
    @IBOutlet weak var myPhoto: UIImageView!
    
    let options = ["Good", "Fair", "Bad"]
    var equipment: [String] = []
    var set: [Int] = []
    var repetitions: [Int] = []
    var sleep = 0
    var weight_value = 0.0
    var bodyFat_value = 0.0
    var fatigue_value = 0
    var first_time = false
    var index = -1
    
    let picker = UIImagePickerController()
    var img = UIImage()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if !first_time {
            sleepHour.text = String(sleep)
            weight.text = String(weight_value)
            bodyFat.text = String(bodyFat_value)
            myPhoto.image = img
            myPhoto.contentMode = .scaleAspectFit
        }
        if fatigue_value != 0 {
            fatigue.setTitle(options[fatigue_value-1], for: .normal)
        }
        tableView.rowHeight = UITableViewAutomaticDimension
        picker.delegate = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //text field
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    //picker view
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return options.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return options[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        fatigue.setTitle(options[row], for: .normal)
        fatigue_value = row+1
    }
    
    //change state of pickerView (fatigue)
    @IBAction func chooseFatigue(_ sender: UIButton) {
        print("chooseFatigue")
        pickerView.isHidden = !pickerView.isHidden
        if pickerView.isHidden {
            myPhoto.frame.size = CGSize(width: myPhoto.frame.width, height: 223)
        }
        else {
            myPhoto.frame.size = CGSize(width: myPhoto.frame.width, height: 130)
        }
    }
    
    //table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return equipment.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "recordDetailCell", for: indexPath) as! recordDetailCell
        cell.equipLabel.text = equipment[indexPath.row]
        cell.setLabel.text = String(set[indexPath.row])
        cell.repLabel.text = String(repetitions[indexPath.row])
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myPhoto.isUserInteractionEnabled = false
        fatigue.isUserInteractionEnabled = false
        customViewAnimated(position: 300)
        index = indexPath.row
        setText.text = String(set[index])
        repText.text = String(repetitions[index])
    }

    //save data in custom view to local data
    @IBAction func customSave(_ sender: UIButton) {
        print("customSave")
        if setText.hasText, let number = Int(setText.text!) {
            set[index] = number
        }
        else {
            set[index] = 0
        }
        
        if repText.hasText, let number2 = Int(repText.text!) {
            repetitions[index] = number2
        }
        else {
            repetitions[index] = 0
        }
        
        customViewAnimated(position: 1000)
        tableView.reloadData()
        myPhoto.isUserInteractionEnabled = true
        fatigue.isUserInteractionEnabled = true
    }
    
    //movement of custom view
    func customViewAnimated(position: Int){
        guard let infoView = customView else{
            return
        }
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseOut, animations: {()-> Void
            in infoView.center.y = CGFloat(position)}, completion: nil)
    }
    
    //leave the view controller
    @IBAction func back(_ sender: UIBarButtonItem) {
        print("back")
        dismiss(animated: true, completion: nil)
    }
    
    //store sleepHour and weight data to local data
    @IBAction func saveButton(_ sender: UIBarButtonItem) {
        print("saveButton")
        if sleepHour.hasText, let hour = Int(sleepHour.text!) {
            sleep = hour
        }
        if weight.hasText, let number3 = Double(weight.text!) {
            weight_value = number3
        }
    }
  
    
    
    @IBAction func choosePhoto(_ sender: UITapGestureRecognizer) {
        // Do any additional setup after loading the view.
        let alert = UIAlertController(title: "Select a photo or share your photo", message: "Choose a method", preferredStyle: .alert)
        
        let lib = UIAlertAction(title: "From photo library", style: .default,
                                handler: {action in
                                    self.fromLib()})
        let camera = UIAlertAction(title: "Take a picture", style: .default,
                                   handler: {action in
                                    self.fromCamera()})
        let share = UIAlertAction(title: "Share to Facebook", style: .default,
                                   handler: {action in
                                    self.sharePhoto()})
        let cancel = UIAlertAction(title: "Cancel", style: .default,
                                  handler: nil)
        alert.addAction(lib)
        alert.addAction(camera)
        alert.addAction(share)
        alert.addAction(cancel)
        present(alert, animated: true, completion: nil)
    }
    
    func fromLib(){
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion:nil)
    }
    
    func fromCamera(){
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            picker.sourceType = .camera
            present(picker, animated: true, completion:nil)
        }
        else{
            print("Camera not available")
        }
    }
    
    func sharePhoto(){
        if let controller = SLComposeViewController(forServiceType: SLServiceTypeFacebook) {
            controller.setInitialText("Good photo deserves good audience.")
            controller.add(myPhoto.image)
            //controller.add(URL(string: urlString))
            present(controller, animated: true)
        }
    }
    
    var selectedImage: UIImage? {
        willSet(image){
            //view.backgroundColor = UIColor(patternImage: image!)
        }
    }
}

extension recordDetailViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let possibleImage = info["UIImagePickerControllerEditedImage"] as? UIImage {
            selectedImage = possibleImage
        }
        else if let possibleImage = info["UIImagePickerControllerOriginalImage"] as? UIImage {
            selectedImage = possibleImage
        }
        else{
            return
        }
        
        myPhoto.image = selectedImage
        myPhoto.contentMode = .scaleAspectFit
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    
}
